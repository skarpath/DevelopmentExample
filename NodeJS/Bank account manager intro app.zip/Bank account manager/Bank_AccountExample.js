//Bank account example
//Node basics 

//Account into
var account = {
	balance: 0
}

//Deposit
function deposit(acount, amout){
	account.balance += amout;
}

//Withdrawl
function Withdrawl(acount, amout){
	account.balance += amout;
}


//getBalance
function getBalance(acount){
	return acount.balance;
}


//deposit money;
deposit(account, 1000);

console.log("$ "+ getBalance(account));


Withdrawl(account, 121);

console.log("$ "+ getBalance(account));