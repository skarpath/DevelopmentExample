//Bank account example
//Node basics 

var accounts = [];

//Account into
//Balance
//Username
//




//Create account
//push onto accounts array
//return account
function createAccount(account){
	accounts.push(account);
	return account;
}


//get account
//find matching account using forEach
function getAccount(username) {
	var matchedAccount;
	
	accounts.forEach(function (account) {
		if(account.username === username)
		{
			matchedAccount = account;
		}
	});
	
	return matchedAccount;
}




//Deposit
function deposit(account, amount){
	account.balance += amount;
}

//Withdrawl
function Withdrawl(account, amount){
	account.balance -= amount;
}


//getBalance
function getBalance(account){
	return account.balance;
}


//Create new account Stephen;
var newAccount = createAccount({
	username: 'Stephen',
	balance: 0
});



deposit(newAccount, 100); //Deposit into Stephens account
console.log("$ "+ getBalance(newAccount));


Withdrawl(newAccount, 11); //Withdrawl from  Stephens account
console.log("$ "+ getBalance(newAccount));


var existingAccount = getAccount(newAccount);



//Create new account Jens;
var newAccount = createAccount({
	username: 'Jen001',
	balance: 12
});


console.log(accounts);


var existingJensAccount = getAccount('Jen001');
console.log(existingJensAccount);






















