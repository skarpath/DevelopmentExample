//Bank account example
//Node basics 

var accounts = [];





//Create account
//push onto accounts array
//return account
function createAccount(account){
	accounts.push(account);
	return account;
}


//get account
//find matching account using forEach
function getAccount(username) {
	var matchedAccount;
	
	//Change to for loop or while loop
	for (var i = 0; i < accounts.length; i++)
	{
		if(accounts[i].username === username)
		{
			matchedAccount = accounts[i];
		}		
	}	
	return matchedAccount;
		
}




//Deposit
function deposit(account, amount)
{
	if (typeof amount == 'number' )
	{
		account.balance += amount;
	}
	else
	{
		console.log('deposit failed, amout is not a number');
	}
}

//Withdrawl
function Withdrawl(account, amount)
{
	if (typeof amount == Number )
	{
		account.balance -= amount;
	}
	else
	{
		console.log('withdrawl failed, amout is not a number');
	}
}


//getBalance
function getBalance(account){
	return account.balance;
}





//Get balance getter
function getBalance(account){
	return function()
	{
		return account.balance;
	}
}






//Create new account Stephen;
var newAccount = createAccount({
	username: 'Stephen',
	balance: 0
});

deposit(newAccount, 120);
Withdrawl(newAccount, 'my string');

var Stephen2 = getAccount('Stephen');

var getAccount2Balance = getBalance(Stephen2);

console.log(getAccount2Balance())


















